"""
EUR-Lex MCP Server
Exposes 7 tools via the Model Context Protocol (stdio transport).
Connect this to Claude Desktop, Claude Code, VS Code, Cursor, etc.
for direct RAG over EU legislation.

Run:  python -m app.mcp_server
"""
import json
import asyncio
import logging

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .eurlex_client import EurLexClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Server("eurlex-mcp-server")
client = EurLexClient()


# ── Tool definitions ───────────────────────────────────────────────

TOOLS = [
    Tool(
        name="eurlex_search",
        description="Search EUR-Lex for EU legislation (regulations, directives, decisions, case law). Returns metadata: CELEX number, title, date, type, in-force status, EUR-Lex URL.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search term (matched against document titles), e.g. 'artificial intelligence'"},
                "resource_type": {"type": "string", "enum": ["REG", "DIR", "DEC", "JUDG", "RECO", "any"], "default": "any", "description": "Filter by document type"},
                "language": {"type": "string", "enum": ["ENG", "DEU", "FRA"], "default": "ENG", "description": "Language for titles"},
                "date_from": {"type": "string", "description": "Filter from date (YYYY-MM-DD)"},
                "date_to": {"type": "string", "description": "Filter to date (YYYY-MM-DD)"},
                "in_force_only": {"type": "boolean", "default": False, "description": "Only return documents currently in force"},
                "limit": {"type": "integer", "default": 10, "minimum": 1, "maximum": 50},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="eurlex_fetch",
        description="Retrieve the full text of an EU legal document by its CELEX identifier. Use this to get the actual content of a regulation, directive, decision, or judgment for RAG context.",
        inputSchema={
            "type": "object",
            "properties": {
                "celex_id": {"type": "string", "description": "CELEX identifier, e.g. '32024R1689' for the AI Act"},
                "language": {"type": "string", "enum": ["ENG", "DEU", "FRA"], "default": "ENG"},
                "format": {"type": "string", "enum": ["xhtml", "plain"], "default": "plain", "description": "Output format: 'plain' strips HTML tags"},
                "max_chars": {"type": "integer", "default": 20000, "minimum": 1000, "maximum": 50000},
            },
            "required": ["celex_id"],
        },
    ),
    Tool(
        name="eurlex_metadata",
        description="Get structured metadata for a document: dates, EuroVoc descriptors, legal basis, in-force status, ELI identifier.",
        inputSchema={
            "type": "object",
            "properties": {
                "celex_id": {"type": "string", "description": "CELEX identifier"},
                "language": {"type": "string", "enum": ["ENG", "DEU", "FRA"], "default": "ENG"},
            },
            "required": ["celex_id"],
        },
    ),
    Tool(
        name="eurlex_citations",
        description="Explore the citation graph: which acts a document cites (outgoing) and which acts cite it (incoming).",
        inputSchema={
            "type": "object",
            "properties": {
                "celex_id": {"type": "string", "description": "CELEX identifier"},
                "direction": {"type": "string", "enum": ["cites", "cited_by", "both"], "default": "both"},
                "language": {"type": "string", "enum": ["ENG", "DEU", "FRA"], "default": "ENG"},
                "limit": {"type": "integer", "default": 20, "minimum": 1, "maximum": 100},
            },
            "required": ["celex_id"],
        },
    ),
    Tool(
        name="eurlex_by_eurovoc",
        description="Find documents by EuroVoc thesaurus concept. EuroVoc is the EU's standardized taxonomy covering all policy domains.",
        inputSchema={
            "type": "object",
            "properties": {
                "concept": {"type": "string", "description": "EuroVoc concept label (e.g. 'artificial intelligence') or URI"},
                "resource_type": {"type": "string", "enum": ["REG", "DIR", "DEC", "JUDG", "RECO", "any"], "default": "any"},
                "language": {"type": "string", "enum": ["ENG", "DEU", "FRA"], "default": "ENG"},
                "limit": {"type": "integer", "default": 10, "minimum": 1, "maximum": 50},
            },
            "required": ["concept"],
        },
    ),
    Tool(
        name="eurlex_consolidated",
        description="Retrieve the consolidated (in-force) version of a regulation, directive, or decision. Returns the current legal text with all amendments applied.",
        inputSchema={
            "type": "object",
            "properties": {
                "doc_type": {"type": "string", "enum": ["reg", "dir", "dec"], "description": "reg=regulation, dir=directive, dec=decision"},
                "year": {"type": "integer", "description": "Year of the act, e.g. 2024"},
                "number": {"type": "integer", "description": "Document number, e.g. 1689"},
                "language": {"type": "string", "enum": ["ENG", "DEU", "FRA"], "default": "ENG"},
                "format": {"type": "string", "enum": ["xhtml", "plain"], "default": "plain"},
                "max_chars": {"type": "integer", "default": 20000},
            },
            "required": ["doc_type", "year", "number"],
        },
    ),
    Tool(
        name="eurlex_changes",
        description="Get documents published or modified since a given date. Useful for monitoring legislative changes.",
        inputSchema={
            "type": "object",
            "properties": {
                "since": {"type": "string", "description": "Date to check from (YYYY-MM-DD)"},
                "resource_type": {"type": "string", "enum": ["REG", "DIR", "DEC", "JUDG", "RECO", "any"], "default": "any"},
                "language": {"type": "string", "enum": ["ENG", "DEU", "FRA"], "default": "ENG"},
                "limit": {"type": "integer", "default": 50, "minimum": 1, "maximum": 200},
            },
            "required": ["since"],
        },
    ),
]


# ── Handlers ───────────────────────────────────────────────────────

@app.list_tools()
async def list_tools():
    return TOOLS


@app.call_tool()
async def call_tool(name: str, arguments: dict):
    try:
        result = await asyncio.to_thread(_dispatch, name, arguments)
        return [TextContent(type="text", text=json.dumps(result, indent=2, ensure_ascii=False))]
    except Exception as e:
        logger.error(f"Tool {name} failed: {e}")
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


def _dispatch(name: str, args: dict):
    if name == "eurlex_search":
        docs = client.search(
            query=args["query"],
            resource_type=args.get("resource_type", "any"),
            language=args.get("language", ""),
            date_from=args.get("date_from", ""),
            date_to=args.get("date_to", ""),
            in_force_only=args.get("in_force_only", False),
            limit=args.get("limit", 10),
        )
        return {"count": len(docs), "results": [d.to_dict() for d in docs]}

    elif name == "eurlex_fetch":
        text = client.fetch_text(
            celex=args["celex_id"],
            language=args.get("language", ""),
            fmt=args.get("format", "plain"),
            max_chars=args.get("max_chars", 0),
        )
        return {"celex": args["celex_id"], "text": text, "chars": len(text)}

    elif name == "eurlex_metadata":
        doc = client.metadata(args["celex_id"], args.get("language", ""))
        return doc.to_dict() if doc else {"error": "Document not found"}

    elif name == "eurlex_citations":
        return client.citations(
            celex=args["celex_id"],
            direction=args.get("direction", "both"),
            language=args.get("language", ""),
            limit=args.get("limit", 20),
        )

    elif name == "eurlex_by_eurovoc":
        concept = args["concept"]
        lang = args.get("language", "") or "ENG"
        lang_tag = lang[:2].lower()
        # resolve label -> URI if needed
        if not concept.startswith("http"):
            escaped = concept.replace('"', '\\"')
            q = f"""PREFIX skos:<http://www.w3.org/2004/02/skos/core#>
SELECT ?concept WHERE {{
  ?concept a skos:Concept.
  ?concept skos:prefLabel ?label.
  FILTER(LCASE(STR(?label)) = LCASE("{escaped}"))
}} LIMIT 1"""
            res = client._sparql(q)
            bindings = res.get("results", {}).get("bindings", [])
            if not bindings:
                return {"error": f"EuroVoc concept '{concept}' not found"}
            concept = bindings[0]["concept"]["value"]

        rt = args.get("resource_type", "any")
        tf = client._type_filter(rt)
        q = f"""{CDM}
SELECT DISTINCT ?work ?celex ?title ?date ?type WHERE {{
  ?work cdm:work_is_about_concept_eurovoc <{concept}>.
  ?work cdm:work_has_resource-type ?type.
  {tf}
  OPTIONAL {{ ?work cdm:resource_legal_id_celex ?celex. }}
  OPTIONAL {{ ?work cdm:work_has_expression ?e.
    ?e cdm:expression_uses_language <{LANG_BASE}/{lang}>.
    ?e cdm:expression_title ?title. }}
  OPTIONAL {{ ?work cdm:work_date_document ?date. }}
}} ORDER BY DESC(?date) LIMIT {args.get('limit', 10)}"""
        docs = client._parse_bindings(client._sparql(q))
        return {"concept": concept, "count": len(docs), "results": [d.to_dict() for d in docs]}

    elif name == "eurlex_consolidated":
        text = client.consolidated(
            doc_type=args["doc_type"],
            year=args["year"],
            number=args["number"],
            language=args.get("language", ""),
            fmt=args.get("format", "plain"),
            max_chars=args.get("max_chars", 0),
        )
        return {"text": text, "chars": len(text)}

    elif name == "eurlex_changes":
        docs = client.recent_documents(
            since=args["since"],
            resource_type=args.get("resource_type", "any"),
            language=args.get("language", ""),
            limit=args.get("limit", 50),
        )
        return {"since": args["since"], "count": len(docs), "results": [d.to_dict() for d in docs]}

    return {"error": f"Unknown tool: {name}"}


# ── Entry point ────────────────────────────────────────────────────

async def main():
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
