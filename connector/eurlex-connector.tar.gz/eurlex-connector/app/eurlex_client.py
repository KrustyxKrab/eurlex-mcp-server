"""
EUR-Lex CELLAR SPARQL & REST client.
Modeled after the Honeyfield MCP server's query patterns, ported to Python.
Both the MCP server and the FastAPI HTTP layer import this.
"""
import re
import time
import logging
from dataclasses import dataclass, field, asdict
from typing import Optional

import httpx

from . import config

logger = logging.getLogger(__name__)

# ── CDM ontology prefixes ──────────────────────────────────────────

CDM = """
PREFIX cdm: <http://publications.europa.eu/ontology/cdm#>
PREFIX annot: <http://publications.europa.eu/ontology/annotation#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
PREFIX dc: <http://purl.org/dc/elements/1.1/>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
"""

# ── Resource type URI fragments ────────────────────────────────────

RESOURCE_TYPES: dict[str, list[str]] = {
    "REG":      ["REG", "REG_IMPL", "REG_FINANC", "REG_DEL"],
    "DIR":      ["DIR", "DIR_IMPL", "DIR_DEL"],
    "DEC":      ["DEC", "DEC_IMPL", "DEC_DEL"],
    "JUDG":     ["JUDG", "ORDER", "OPIN_JUR", "VIEW_AG"],
    "RECO":     ["RECOMMEND"],
    "any":      [],  # no filter
}

RT_BASE = "http://publications.europa.eu/resource/authority/resource-type"
LANG_BASE = "http://publications.europa.eu/resource/authority/language"


# ── Data classes ───────────────────────────────────────────────────

@dataclass
class EurLexDoc:
    cellar_uri: str
    celex: str = ""
    title: str = ""
    date_document: str = ""
    resource_type: str = ""
    in_force: str = ""
    eli: str = ""
    url: str = ""
    text: str = ""
    eurovoc: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ChangeRecord:
    celex: str
    title: str
    resource_type: str
    date_document: str
    change_type: str  # "new" | "modified"
    detected_at: str
    url: str
    eli: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


# ── Client ─────────────────────────────────────────────────────────

class EurLexClient:
    def __init__(self):
        self._http = httpx.Client(
            timeout=config.SPARQL_TIMEOUT,
            follow_redirects=True,
        )
        self._last_req = 0.0

    def close(self):
        self._http.close()

    # ── throttle ───────────────────────────────────────────────────

    def _throttle(self):
        gap = time.time() - self._last_req
        if gap < config.THROTTLE_INTERVAL:
            time.sleep(config.THROTTLE_INTERVAL - gap)
        self._last_req = time.time()

    # ── raw SPARQL ─────────────────────────────────────────────────

    def _sparql(self, query: str) -> dict:
        self._throttle()
        r = self._http.post(
            config.SPARQL_ENDPOINT,
            data={"query": query},
            headers={"Accept": "application/sparql-results+json"},
        )
        r.raise_for_status()
        return r.json()

    # ── helpers ────────────────────────────────────────────────────

    @staticmethod
    def _type_filter(resource_type: str) -> str:
        if resource_type == "any" or resource_type not in RESOURCE_TYPES:
            return ""
        uris = RESOURCE_TYPES[resource_type]
        clauses = "||".join(f"?type=<{RT_BASE}/{u}>" for u in uris)
        return f"FILTER({clauses})"

    @staticmethod
    def _type_label(uri: str) -> str:
        return uri.rsplit("/", 1)[-1] if "/" in uri else uri

    def _parse_bindings(self, data: dict) -> list[EurLexDoc]:
        seen, docs = set(), []
        for b in data.get("results", {}).get("bindings", []):
            uri = b.get("work", {}).get("value", "")
            if uri in seen:
                continue
            seen.add(uri)
            celex = b.get("celex", {}).get("value", "")
            docs.append(EurLexDoc(
                cellar_uri=uri,
                celex=celex,
                title=b.get("title", {}).get("value", ""),
                date_document=b.get("date", {}).get("value", ""),
                resource_type=self._type_label(b.get("type", {}).get("value", "")),
                in_force=b.get("force", {}).get("value", ""),
                eli=b.get("eli", {}).get("value", ""),
                url=f"https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:{celex}" if celex else "",
            ))
        return docs

    # ── Tool 1: search ─────────────────────────────────────────────

    def search(
        self,
        query: str = "",
        resource_type: str = "any",
        language: str = "",
        date_from: str = "",
        date_to: str = "",
        in_force_only: bool = False,
        limit: int = 25,
        offset: int = 0,
    ) -> list[EurLexDoc]:
        lang = language or config.DEFAULT_LANGUAGE
        tf = self._type_filter(resource_type)
        parts = [f'{CDM}SELECT DISTINCT ?work ?celex ?title ?date ?type ?force ?eli WHERE {{']
        parts.append('  ?work cdm:work_has_resource-type ?type.')
        if tf:
            parts.append(f'  {tf}')
        parts.append('  FILTER NOT EXISTS { ?work cdm:do_not_index "true"^^xsd:boolean }')
        parts.append('  OPTIONAL { ?work cdm:resource_legal_id_celex ?celex. }')
        parts.append(f'  OPTIONAL {{ ?work cdm:work_has_expression ?expr. ?expr cdm:expression_uses_language <{LANG_BASE}/{lang}>. ?expr cdm:expression_title ?title. }}')
        parts.append('  OPTIONAL { ?work cdm:work_date_document ?date. }')
        parts.append('  OPTIONAL { ?work cdm:resource_legal_in-force ?force. }')
        parts.append('  OPTIONAL { ?work cdm:resource_legal_eli ?eli. }')
        if query:
            escaped = query.replace('"', '\\"')
            parts.append(f'  FILTER(CONTAINS(LCASE(?title), LCASE("{escaped}")))')
        if date_from:
            parts.append(f'  FILTER(?date >= "{date_from}"^^xsd:date)')
        if date_to:
            parts.append(f'  FILTER(?date <= "{date_to}"^^xsd:date)')
        if in_force_only:
            parts.append('  FILTER(?force = "true"^^xsd:boolean)')
        parts.append(f'}} ORDER BY DESC(?date) LIMIT {limit} OFFSET {offset}')
        return self._parse_bindings(self._sparql("\n".join(parts)))

    # ── Tool 2: fetch document text ────────────────────────────────

    def fetch_text(
        self,
        celex: str,
        language: str = "",
        fmt: str = "xhtml",
        max_chars: int = 0,
    ) -> str:
        lang = (language or config.DEFAULT_LANGUAGE)[:2].lower()  # ENG -> en
        max_c = max_chars or config.MAX_DOCUMENT_CHARS
        accept = "application/xhtml+xml, text/html;q=0.9" if fmt == "xhtml" else "text/plain, text/html;q=0.8"
        # resolve CELEX -> CELLAR URI
        q = f'{CDM}SELECT ?work WHERE {{ ?work cdm:resource_legal_id_celex "{celex}". }} LIMIT 1'
        res = self._sparql(q)
        bindings = res.get("results", {}).get("bindings", [])
        if not bindings:
            return ""
        uri = bindings[0]["work"]["value"]
        self._throttle()
        try:
            r = self._http.get(uri, headers={"Accept": accept, "Accept-Language": lang})
            r.raise_for_status()
            text = r.text
            if fmt == "plain":
                text = re.sub(r"<[^>]+>", " ", text)
                text = re.sub(r"\s+", " ", text).strip()
            return text[:max_c]
        except Exception as e:
            logger.warning(f"fetch_text({celex}): {e}")
            return ""

    # ── Tool 3: metadata ──────────────────────────────────────────

    def metadata(self, celex: str, language: str = "") -> Optional[EurLexDoc]:
        lang = language or config.DEFAULT_LANGUAGE
        q = f"""{CDM}
SELECT DISTINCT ?work ?title ?date ?type ?force ?eli WHERE {{
  ?work cdm:resource_legal_id_celex "{celex}".
  ?work cdm:work_has_resource-type ?type.
  OPTIONAL {{ ?work cdm:work_has_expression ?expr.
    ?expr cdm:expression_uses_language <{LANG_BASE}/{lang}>.
    ?expr cdm:expression_title ?title. }}
  OPTIONAL {{ ?work cdm:work_date_document ?date. }}
  OPTIONAL {{ ?work cdm:resource_legal_in-force ?force. }}
  OPTIONAL {{ ?work cdm:resource_legal_eli ?eli. }}
}} LIMIT 1"""
        docs = self._parse_bindings(self._sparql(q))
        if not docs:
            return None
        doc = docs[0]
        doc.celex = celex
        doc.url = f"https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:{celex}"
        doc.eurovoc = self.eurovoc(celex, lang)
        return doc

    # ── Tool 4: EuroVoc subjects ──────────────────────────────────

    def eurovoc(self, celex: str, language: str = "") -> list[str]:
        lang_tag = (language or config.DEFAULT_LANGUAGE)[:2].lower()
        q = f"""{CDM}
SELECT DISTINCT ?label WHERE {{
  ?work cdm:resource_legal_id_celex "{celex}".
  ?work cdm:work_is_about_concept_eurovoc ?concept.
  ?concept skos:prefLabel ?label.
  FILTER(LANG(?label) = "{lang_tag}")
}} LIMIT 30"""
        try:
            res = self._sparql(q)
            return [b["label"]["value"] for b in res.get("results", {}).get("bindings", [])]
        except Exception:
            return []

    # ── Tool 5: citations ─────────────────────────────────────────

    def citations(
        self,
        celex: str,
        direction: str = "both",
        language: str = "",
        limit: int = 20,
    ) -> dict:
        lang = language or config.DEFAULT_LANGUAGE
        out: dict = {"celex": celex, "cites": [], "cited_by": []}

        if direction in ("cites", "both"):
            q = f"""{CDM}
SELECT DISTINCT ?cited ?cited_celex ?cited_title WHERE {{
  ?work cdm:resource_legal_id_celex "{celex}".
  ?work cdm:work_cites_work ?cited.
  OPTIONAL {{ ?cited cdm:resource_legal_id_celex ?cited_celex. }}
  OPTIONAL {{ ?cited cdm:work_has_expression ?e. ?e cdm:expression_uses_language <{LANG_BASE}/{lang}>. ?e cdm:expression_title ?cited_title. }}
}} LIMIT {limit}"""
            for b in self._sparql(q).get("results", {}).get("bindings", []):
                out["cites"].append({
                    "celex": b.get("cited_celex", {}).get("value", ""),
                    "title": b.get("cited_title", {}).get("value", ""),
                })

        if direction in ("cited_by", "both"):
            q = f"""{CDM}
SELECT DISTINCT ?citing ?citing_celex ?citing_title WHERE {{
  ?work cdm:resource_legal_id_celex "{celex}".
  ?citing cdm:work_cites_work ?work.
  OPTIONAL {{ ?citing cdm:resource_legal_id_celex ?citing_celex. }}
  OPTIONAL {{ ?citing cdm:work_has_expression ?e. ?e cdm:expression_uses_language <{LANG_BASE}/{lang}>. ?e cdm:expression_title ?citing_title. }}
}} LIMIT {limit}"""
            for b in self._sparql(q).get("results", {}).get("bindings", []):
                out["cited_by"].append({
                    "celex": b.get("citing_celex", {}).get("value", ""),
                    "title": b.get("citing_title", {}).get("value", ""),
                })
        return out

    # ── Tool 6: consolidated version ──────────────────────────────

    def consolidated(
        self,
        doc_type: str,
        year: int,
        number: int,
        language: str = "",
        fmt: str = "xhtml",
        max_chars: int = 0,
    ) -> str:
        type_map = {"reg": "R", "dir": "L", "dec": "D"}
        letter = type_map.get(doc_type, "R")
        celex = f"0{year}{letter}{number:04d}"
        return self.fetch_text(celex, language, fmt, max_chars)

    # ── Tool 7: recent changes (for change tracker) ───────────────

    def recent_documents(
        self,
        since: str,
        resource_type: str = "any",
        language: str = "",
        limit: int = 200,
    ) -> list[EurLexDoc]:
        return self.search(
            resource_type=resource_type,
            language=language,
            date_from=since,
            limit=limit,
        )
