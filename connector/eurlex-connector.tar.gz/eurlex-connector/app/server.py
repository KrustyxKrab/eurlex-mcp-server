"""
FastAPI HTTP server — REST wrapper over the EUR-Lex client.
Power Platform Custom Connector calls these endpoints.
Copilot Studio uses the RAG endpoints; Power Automate uses /changes.

Run:  uvicorn app.server:app --host 0.0.0.0 --port 8000
"""
import logging
from typing import Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, Query, HTTPException, Depends, Security
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from . import config
from .eurlex_client import EurLexClient
from .change_tracker import ChangeTracker

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_client: EurLexClient = None  # type: ignore
_tracker: ChangeTracker = None  # type: ignore


@asynccontextmanager
async def lifespan(application: FastAPI):
    global _client, _tracker
    _client = EurLexClient()
    _tracker = ChangeTracker()
    logger.info("EUR-Lex connector started")
    yield
    _client.close()
    logger.info("EUR-Lex connector stopped")

app = FastAPI(
    title="EUR-Lex Connector",
    description="REST API for EU legislation search, document retrieval, and change tracking. Designed as a backend for Microsoft Power Platform Custom Connectors.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Optional API key auth ──────────────────────────────────────────

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

async def verify_key(key: Optional[str] = Security(api_key_header)):
    if config.API_KEY and key != config.API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")


# ── Response models ────────────────────────────────────────────────

class DocResult(BaseModel):
    cellar_uri: str = ""
    celex: str = ""
    title: str = ""
    date_document: str = ""
    resource_type: str = ""
    in_force: str = ""
    eli: str = ""
    url: str = ""

class SearchResponse(BaseModel):
    count: int
    results: list[DocResult]

class FetchResponse(BaseModel):
    celex: str
    text: str
    chars: int

class MetadataResponse(BaseModel):
    celex: str = ""
    title: str = ""
    date_document: str = ""
    resource_type: str = ""
    in_force: str = ""
    eli: str = ""
    url: str = ""
    eurovoc: list[str] = []

class ChangeItem(BaseModel):
    celex: str
    title: str
    resource_type: str
    date_document: str
    change_type: str
    detected_at: str
    url: str
    eli: str = ""

class ChangesResponse(BaseModel):
    last_check: str | None
    count: int
    new_count: int
    modified_count: int
    changes: list[ChangeItem]


# ── Endpoints ──────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "service": "eurlex-connector"}


@app.get("/search", response_model=SearchResponse, dependencies=[Depends(verify_key)])
async def search(
    query: str = Query(..., min_length=1, description="Search term matched against document titles"),
    resource_type: str = Query("any", description="REG, DIR, DEC, JUDG, RECO, or any"),
    language: str = Query("ENG", description="ENG, DEU, or FRA"),
    date_from: str = Query("", description="Filter from date (YYYY-MM-DD)"),
    date_to: str = Query("", description="Filter to date (YYYY-MM-DD)"),
    in_force_only: bool = Query(False),
    limit: int = Query(10, ge=1, le=50),
    offset: int = Query(0, ge=0),
):
    """Search EUR-Lex legislation. Used by Copilot Studio as a RAG search action."""
    docs = _client.search(query, resource_type, language, date_from, date_to, in_force_only, limit, offset)
    return SearchResponse(count=len(docs), results=[DocResult(**d.to_dict()) for d in docs])


@app.get("/fetch/{celex_id}", response_model=FetchResponse, dependencies=[Depends(verify_key)])
async def fetch(
    celex_id: str,
    language: str = Query("ENG"),
    format: str = Query("plain", description="xhtml or plain"),
    max_chars: int = Query(20000, ge=1000, le=50000),
):
    """Fetch the full text of a document by CELEX number. Core RAG retrieval endpoint."""
    text = _client.fetch_text(celex_id, language, format, max_chars)
    if not text:
        raise HTTPException(404, f"Document {celex_id} not found or no text available")
    return FetchResponse(celex=celex_id, text=text, chars=len(text))


@app.get("/metadata/{celex_id}", response_model=MetadataResponse, dependencies=[Depends(verify_key)])
async def metadata(
    celex_id: str,
    language: str = Query("ENG"),
):
    """Get structured metadata: dates, EuroVoc, legal basis, in-force status."""
    doc = _client.metadata(celex_id, language)
    if not doc:
        raise HTTPException(404, f"Document {celex_id} not found")
    return MetadataResponse(**doc.to_dict())


@app.get("/citations/{celex_id}", dependencies=[Depends(verify_key)])
async def citations(
    celex_id: str,
    direction: str = Query("both", description="cites, cited_by, or both"),
    language: str = Query("ENG"),
    limit: int = Query(20, ge=1, le=100),
):
    """Explore which acts a document cites and which cite it."""
    return _client.citations(celex_id, direction, language, limit)


@app.get("/changes", response_model=ChangesResponse, dependencies=[Depends(verify_key)])
async def changes(
    resource_type: str = Query("any"),
    language: str = Query("ENG"),
    limit: int = Query(200, ge=1, le=500),
):
    """
    Poll for changes since last check. Power Automate calls this on a schedule.
    Returns new and modified documents. State is persisted between calls.
    The first call returns everything from the 1st of the current month.
    """
    change_list = _tracker.poll(_client, resource_type, language, limit)
    new_ct = sum(1 for c in change_list if c.change_type == "new")
    return ChangesResponse(
        last_check=_tracker.last_check,
        count=len(change_list),
        new_count=new_ct,
        modified_count=len(change_list) - new_ct,
        changes=[ChangeItem(**c.to_dict()) for c in change_list],
    )


@app.post("/changes/reset", dependencies=[Depends(verify_key)])
async def reset_tracker():
    """Reset change tracking state. Next poll will treat everything as new."""
    _tracker.reset()
    return {"status": "reset", "message": "Tracker state cleared"}
