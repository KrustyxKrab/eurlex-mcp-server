"""
Change tracker — diffs EUR-Lex state against last known snapshot.
Persists to JSON in DATA_DIR. Power Automate polls the HTTP endpoint
that calls this, then handles Excel + email natively.
"""
import json
import hashlib
import logging
from datetime import datetime, timezone
from pathlib import Path

from . import config
from .eurlex_client import EurLexClient, ChangeRecord

logger = logging.getLogger(__name__)


class ChangeTracker:
    def __init__(self, state_file: str = "tracker_state.json"):
        self._path = config.DATA_DIR / state_file
        self._state = self._load()

    def _load(self) -> dict:
        if self._path.exists():
            with open(self._path) as f:
                return json.load(f)
        return {"last_check": None, "known": {}}

    def _save(self):
        with open(self._path, "w") as f:
            json.dump(self._state, f, indent=2, default=str)

    @staticmethod
    def _hash(title: str, date: str, force: str) -> str:
        return hashlib.sha256(f"{title}|{date}|{force}".encode()).hexdigest()[:16]

    @property
    def last_check(self) -> str | None:
        return self._state.get("last_check")

    def poll(
        self,
        client: EurLexClient,
        resource_type: str = "any",
        language: str = "",
        limit: int = 200,
    ) -> list[ChangeRecord]:
        since = self._state["last_check"][:10] if self._state["last_check"] else datetime.now(timezone.utc).strftime("%Y-%m-01")
        logger.info(f"Polling EUR-Lex for changes since {since}")

        docs = client.recent_documents(since, resource_type, language, limit)
        known = self._state.get("known", {})
        changes: list[ChangeRecord] = []

        for doc in docs:
            if not doc.celex:
                continue
            h = self._hash(doc.title, doc.date_document, doc.in_force)
            prev = known.get(doc.celex)
            if prev is None:
                ct = "new"
            elif prev != h:
                ct = "modified"
            else:
                continue
            changes.append(ChangeRecord(
                celex=doc.celex,
                title=doc.title,
                resource_type=doc.resource_type,
                date_document=doc.date_document,
                change_type=ct,
                detected_at=datetime.now(timezone.utc).isoformat(),
                url=doc.url,
                eli=doc.eli,
            ))
            known[doc.celex] = h

        self._state["last_check"] = datetime.now(timezone.utc).isoformat()
        self._state["known"] = known
        self._save()

        new_ct = sum(1 for c in changes if c.change_type == "new")
        mod_ct = len(changes) - new_ct
        logger.info(f"Found {len(changes)} changes: {new_ct} new, {mod_ct} modified")
        return changes

    def reset(self):
        self._state = {"last_check": None, "known": {}}
        self._save()
