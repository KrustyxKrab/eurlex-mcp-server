"""
Central configuration — all settings from environment variables with sane defaults.
"""
import os
from pathlib import Path

SPARQL_ENDPOINT = os.getenv("EURLEX_SPARQL_ENDPOINT", "https://publications.europa.eu/webapi/rdf/sparql")
CELLAR_BASE = os.getenv("EURLEX_CELLAR_BASE", "https://publications.europa.eu/resource/cellar")

DEFAULT_LANGUAGE = os.getenv("EURLEX_DEFAULT_LANGUAGE", "ENG")
MAX_DOCUMENT_CHARS = int(os.getenv("EURLEX_MAX_DOC_CHARS", "20000"))
SPARQL_TIMEOUT = int(os.getenv("EURLEX_SPARQL_TIMEOUT", "55"))
MAX_CONCURRENT = int(os.getenv("EURLEX_MAX_CONCURRENT", "4"))
THROTTLE_INTERVAL = float(os.getenv("EURLEX_THROTTLE_INTERVAL", "0.5"))

DATA_DIR = Path(os.getenv("EURLEX_DATA_DIR", "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", "8000"))
API_KEY = os.getenv("API_KEY", "")  # optional — set for production

SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
