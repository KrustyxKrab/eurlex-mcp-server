# Power Automate — EUR-Lex Change Notification Flow

Step-by-step guide to build the automated workflow that polls for legislative
changes, writes them to Excel, and sends a notification email.

---

## Prerequisites

- The EUR-Lex Connector API is deployed and reachable (e.g. `https://your-app.azurewebsites.net`)
- You have imported the Custom Connector (see main README)
- You have a SharePoint site or OneDrive folder for the Excel file

---

## Flow overview

```
Recurrence (daily 07:00)
  → GET /changes (Custom Connector)
  → Condition: count > 0?
    YES →
      → Create Excel file (Excel Online)
      → For each change → Add row to table
      → Send email with attachment (Outlook)
    NO →
      → (do nothing)
```

---

## Step-by-step

### 1. Create a new Automated Cloud Flow

- Go to https://make.powerautomate.com
- Click **+ Create** → **Scheduled cloud flow**
- Name: `EUR-Lex Change Monitor`
- Set schedule: every 1 day at 07:00 (or your preference)

### 2. Add the Custom Connector action

- Click **+ New step** → search for your connector name (e.g. "EUR-Lex Connector")
- Select the **GetLegislativeChanges** action
- Parameters:
  - `resource_type`: `any` (or `REG`, `DIR`, etc. if you only care about specific types)
  - `language`: `ENG`
  - `limit`: `200`

### 3. Add a Condition

- Click **+ New step** → **Condition**
- Set: `count` (from the connector output) **is greater than** `0`

### 4. If YES — Create the Excel report

#### 4a. Create the Excel file

- Add action: **Excel Online (Business)** → **Create table**
- Location: your SharePoint site or OneDrive
- File path: `/EUR-Lex Reports/changes_@{formatDateTime(utcNow(), 'yyyy-MM-dd')}.xlsx`
- Table name: `Changes`
- Columns:
  ```
  CELEX | Title | Type | Document Date | Change Type | Detected At | URL | ELI
  ```

#### 4b. Loop through changes

- Add action: **Apply to each**
- Select: `changes` array from the connector output
- Inside the loop, add: **Excel Online (Business)** → **Add a row into a table**
- Map the fields:
  - CELEX → `celex`
  - Title → `title`
  - Type → `resource_type`
  - Document Date → `date_document`
  - Change Type → `change_type`
  - Detected At → `detected_at`
  - URL → `url`
  - ELI → `eli`

### 5. Send the email

- After the loop (but still inside IF YES), add: **Office 365 Outlook** → **Send an email (V2)**
- To: your distribution list or team email
- Subject: `EUR-Lex Changes — @{formatDateTime(utcNow(), 'yyyy-MM-dd')} — @{body('GetLegislativeChanges')?['count']} changes`
- Body (HTML):
  ```html
  <h2>EUR-Lex Legislative Changes</h2>
  <p><b>@{body('GetLegislativeChanges')?['new_count']}</b> new documents,
     <b>@{body('GetLegislativeChanges')?['modified_count']}</b> modified</p>
  <p>Full report attached. Changes tracked since:
     @{body('GetLegislativeChanges')?['last_check']}</p>
  ```
- Attachments:
  - Name: `eurlex_changes_@{formatDateTime(utcNow(), 'yyyy-MM-dd')}.xlsx`
  - Content: use **Get file content** action on the Excel file created in step 4a

### 6. If NO — do nothing

Leave the NO branch empty.

### 7. Save and test

- Click **Save**
- Click **Test** → **Manually** to run it once
- Check your inbox for the email

---

## Alternative: simpler version without Excel

If you just want an email notification without the Excel attachment:

1. Recurrence → GET /changes → Condition (count > 0)
2. If YES → Send email with the JSON body formatted as an HTML table
3. Use this expression to build a simple table:

```
<table border="1">
<tr><th>CELEX</th><th>Title</th><th>Type</th><th>Change</th></tr>
@{join(
  outputs('Apply_to_each')?['body'],
  ''
)}
</table>
```

---

## Tips

- **Frequency**: daily is usually enough — EU legislation doesn't change hourly.
  For critical compliance monitoring, use every 6 hours.
- **Filtering**: set `resource_type` to `REG` if you only care about regulations,
  or `DIR` for directives only. This keeps the email focused.
- **Teams notification**: replace the Outlook step with a **Post message in a chat
  or channel** action to send to a Teams channel instead.
- **The tracker remembers state**: each call to `/changes` only returns what's new
  since the last call. If you need to reset and re-scan, call `POST /changes/reset`.
